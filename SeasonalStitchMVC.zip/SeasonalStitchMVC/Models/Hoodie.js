// models/Hoodie.js
const db = require('../db');

const Hoodie = {
    getAll: function(cb) {
        const sql = 'SELECT * FROM hoodies ORDER BY hoodie_id DESC';
        db.query(sql, (err, results) => {
            if (err) return cb(err);
            cb(null, results);
        });
    },

    getById: function(id, cb) {
        const sql = 'SELECT * FROM hoodies WHERE hoodie_id = ?';
        db.query(sql, [id], (err, results) => {
            if (err) return cb(err);
            cb(null, results[0]);
        });
    },

    add: function(hoodie, cb) {
        const sql = 'INSERT INTO hoodies (name, description, price, image_url, stock, season) VALUES (?, ?, ?, ?, ?, ?)';
        db.query(sql, [
            hoodie.name,
            hoodie.description,
            hoodie.price,
            hoodie.image_url,
            hoodie.stock,
            hoodie.season
        ], cb);
    },

    update: function(id, hoodie, cb) {
        const sql = 'UPDATE hoodies SET name=?, description=?, price=?, image_url=?, stock=?, season=? WHERE hoodie_id=?';
        db.query(sql, [
            hoodie.name,
            hoodie.description,
            hoodie.price,
            hoodie.image_url,
            hoodie.stock,
            hoodie.season,
            id
        ], cb);
    },

    delete: function(id, cb) {
        const sql = 'DELETE FROM hoodies WHERE hoodie_id = ?';
        db.query(sql, [id], cb);
    }
};

module.exports = Hoodie;
