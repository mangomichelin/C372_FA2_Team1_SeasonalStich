const db = require('../db');

const User = {
    authenticate: function(email, password, cb) {
        const sql = 'SELECT * FROM users WHERE email = ? AND password = ?';
        db.query(sql, [email, password], (err, results) => {
            if (err) return cb(err);
            cb(null, results[0]);
        });
    }
};

module.exports = User;